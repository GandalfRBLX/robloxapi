class DetailedTrade:
    def __init__(self, request, ):
        pass
